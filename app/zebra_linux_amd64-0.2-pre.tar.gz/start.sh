#!/usr/bin/env bash

nohup ./zebra > zebra.log 2>&1 &
#
